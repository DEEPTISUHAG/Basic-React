import React from 'react'

export default function Location() {
  return (
    <div>sdfghjk</div>
  )
}
