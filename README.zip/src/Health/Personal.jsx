import React from 'react'

export default function Personal() {
  return (
    <div>Personal</div>
  )
}
